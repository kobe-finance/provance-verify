# Conversation SCEN-batch-828c2a3baba0-0001

**Scenario:** SCEN-batch-828c2a3baba0-0001
**Category:** CAT-01.01
**QA Verdict:** PASS
**QA Score:** 100

## Customer

My bathroom tap has started dripping since last week.

## Assistant

Thanks. That sounds like a worn washer. I'll book a plumber for tomorrow morning to replace it.

---

