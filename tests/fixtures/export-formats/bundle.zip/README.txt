Provance evidence bundle — export export-d05bd64a64dd46f68ce28e0b5e8c70e5

What this is
  The provenance of this export: every record needed to trace it back to its
  first inputs (gold standards, ontology, scenario register, domain
  configuration, model calls), the chains they are on, the signed seal, and
  checkpoint 653e2ea5-bbe5-41e8-8b1e-116b841939e1 (#25), timestamped by http://127.0.0.1:52686/tsr at 2026-10-21T13:10:31+00:00.
  It holds hashes, ids, versions, counts and verdicts only.

How to verify it offline (provance-verify, Apache-2.0, in provance-sdks/verify)
  1. Get the key set from Provance yourself (not from this bundle):
       curl -s <api>/v1/engine/provenance/public-key > provance-keys.json
  2. Get the timestamp authority's certificate from the TSA itself.
  3. Run:
       provance-verify <this bundle>.zip --keys provance-keys.json --tsa-cert tsa.pem [--export <export>.zip]
     --export checks the export archive's own bytes against the seal.

Every file is listed with its SHA-256 in manifest.json, which is signed.
keys.json and tsa-certificates.pem are copies for reference; the verifier
never trusts a key carried in the bundle.
