Provance evidence bundle — export export-8df0a2b72fe544ad88345d94c8966e01

What this is
  The provenance of this export: every record needed to trace it back to its
  first inputs (gold standards, ontology, scenario register, domain
  configuration, model calls), the chains they are on, the signed seal, and
  checkpoint bfbf7db9-9977-4697-822e-2b4c27f69985 (#12), timestamped by http://127.0.0.1:51459/tsr at 2026-10-21T13:40:03+00:00.
  It holds hashes, ids, versions, counts and verdicts only.

How to verify it offline (provance-verify, Apache-2.0, in provance-sdks/verify)
  1. Get the key set from Provance yourself (not from this bundle):
       curl -s <api>/v1/engine/provenance/public-key > provance-keys.json
  2. Get the timestamp authority's certificate from the TSA itself.
  3. Run:
       provance-verify <this bundle>.zip --keys provance-keys.json --tsa-cert tsa.pem [--export <export>.zip]
     --export checks the export archive's own bytes against the seal.

Every file is listed with its SHA-256 in manifest.json, which is signed.
keys.json and tsa-certificates.pem are copies for reference; the verifier
never trusts a key carried in the bundle.
