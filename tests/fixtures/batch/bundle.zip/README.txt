Provance evidence bundle — batch batch-1b3a4c7c468b

What this is
  The provenance of this batch: every record needed to trace it back to its
  first inputs (gold standards, ontology, scenario register, domain
  configuration, model calls), the chains they are on, the signed seal, and
  checkpoint 4c81e213-2cb1-46ea-a81d-460605f9a5c5 (#24), timestamped by http://127.0.0.1:63638/tsr at 2026-10-19T02:40:26+00:00.
  It holds hashes, ids, versions, counts and verdicts only.

How to verify it offline (provance-verify, Apache-2.0, in provance-sdks/verify)
  1. Get the key set from Provance yourself (not from this bundle):
       curl -s <api>/v1/engine/provenance/public-key > provance-keys.json
  2. Get the timestamp authority's certificate from the TSA itself.
  3. Run:
       provance-verify <this bundle>.zip --keys provance-keys.json --tsa-cert tsa.pem [--export <export>.zip]
     --export checks the export archive's own bytes against the seal.

Every file is listed with its SHA-256 in manifest.json, which is signed.
keys.json and tsa-certificates.pem are copies for reference; the verifier
never trusts a key carried in the bundle.
