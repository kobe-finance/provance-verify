# Conversation SCEN-batch-fdeb73412380-0001

**Scenario:** SCEN-batch-fdeb73412380-0001
**Category:** CAT-01.01
**QA Verdict:** PASS
**QA Score:** 100

## Customer

My bathroom tap has started dripping since last week.

## Assistant

Thanks. That sounds like a worn washer. I'll book a plumber for tomorrow morning to replace it.

---

